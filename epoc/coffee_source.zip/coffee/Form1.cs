﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace coffee
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // String recording incoming UART data until a carriage-return is detected
        private string recorder_str = "";

        // Brewing state machine state
        private int brew_state = 0;

        // Current temperature
        int current_temp = 71;

        // Target Temperature
        int target_temp = 206;

        // Brew timer
        int brew_time = 0;

        // 
        bool incoming_control = false;

        // Enumerates available COM ports and places them in a combo box for selection by user
        private void enumeratePorts()
        {
            string[] availableSerialPortNames = System.IO.Ports.SerialPort.GetPortNames();
            if (availableSerialPortNames.Count() > 0)
            {
                // Set the currently selected port to the first port found
                comboBox1.Text = availableSerialPortNames[0];
                // Populate the combo box
                for (int i = 0; i < availableSerialPortNames.Count(); i++)
                    comboBox1.Items.Add(availableSerialPortNames[i]);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Allow calls across threads
            CheckForIllegalCrossThreadCalls = false;
            checkBox1.ForeColor = Color.Red;
            enumeratePorts();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            // if a COM port is already open, then close it first
            if (serialPort1.IsOpen)
                serialPort1.Close();
            serialPort1.PortName = comboBox1.Text;

            // Attempt to open the slected COM port
            try
            {
                serialPort1.Open();
            }
            catch
            {

            }


            // Report status of the attempt to open the COM port
            if (!serialPort1.IsOpen)
            {
                comboBox1.BackColor = Color.Red;
                button1.Enabled = false;
                //log_output(0, "Failed to open COM port\n");
            }
            else
            {
                comboBox1.BackColor = Color.LightGreen;
                button1.Enabled = true;
                //log_output(0, "COM port opened successfully\n");
                //next_cmd();
                serialPort1.Write("ATE=0\r");
            }
        }

        // Helper function to color code logging information
        private void log_output(uint type, string text)
        {
            if (type == 0)
                richTextBox1.SelectionColor = Color.Black;
            if (type == 1)
                richTextBox1.SelectionColor = Color.Green;
            if (type == 2)
                richTextBox1.SelectionColor = Color.Red;
            if (type == 3)
            {
                // use a larger font for this logging type
                richTextBox1.SelectionFont = new Font("Tahoma", 16, FontStyle.Bold);
                richTextBox1.SelectionColor = Color.Blue;
            }
            // Write the formatted text to the log window
            richTextBox1.SelectedText = text;
        }

        private void set_status(string s)
        {
            label6.Text = s;
            transmit_data("|12"+s+"\r");
        }

        private void start_brewing()
        {
            brew_state = 1;
            //current_temp = 71;
            //trackBar1.Value = 71;
            label2.Text = "Current Temperature 71°F";
            set_status("Heating");
        }

        // Parse request from the Bluetooth peer
        private void parse_request(string s)
        {
            string command = s.Substring(1, 2);
            if (command == "00")
            {
                if (s.Substring(3, 1) == "0")
                    checkBox1.Checked = false;
                else
                    checkBox1.Checked = true;
                incoming_control = true;
                set_power_state();
            }
            if (command == "01")
            {
                start_brewing();
            }
            else if (command == "02")
            {
                if (s.Length > 3)
                {
                    target_temp = Int16.Parse(s.Substring(3, s.Length - 3));
                    label4.Text = "Brew starts at " + target_temp + "°F";
                }
            }
            else if (command == "03")
            {

            }
            else if (command == "11")
            {
            }
            else if (command == "13")
            {
            }
            else
            {
            }
        }


        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            {
                // As long as there are bytes in the input buffer...
                while (serialPort1.BytesToRead > 0)
                {
                    // read one byte at the time
                    byte rx = (byte)serialPort1.ReadByte();

                    // Was a carriage-return character received?
                    if ((rx == 0x0D) || (rx == 0x21))
                    {
                        // Place the received data in the log window
                        //log_output(1, "." + recorder_str + "\n");

                        if (recorder_str == "+DISCONNECTED")
                        {
                            label8.Text = "BLE: Disconnected";
                            log_output(0, "Bluetooth Disconnected\n");
                        }
                        if (recorder_str == "+CONNECTED")
                        {
                            log_output(0, "Bluetooth Connected\n");
                            label8.Text = "BLE: Connected";
                        }

                        if (recorder_str.Length > 0)
                        {
                            // Was the received data from the peer Bluetooth device?
                            if (recorder_str.Substring(0, 1) == "|")
                            {
                                // Parse and act on the command from the peer
                                parse_request(recorder_str);
                                log_output(1, "<-- " + recorder_str + "\n");
                            }
                            else
                            {
                                if(checkBox2.Checked)
                                  log_output(0, "<-- " + recorder_str + "\n");
                            }
                        }

                        // We are done with this data set => prepare for a new one 
                        recorder_str = "";
                    }
                    else
                    {
                        // Keep recording bytes from the UART (unless the byte is a new-line)
                        if (rx != 0x0A)
                            recorder_str += ((char)rx).ToString();
                    }
                }
            }
        }

        private void transmit_data(string s)
        {
            if (serialPort1.IsOpen)
            {
                log_output(2, "--> " + s + "\n");
                serialPort1.Write(s + "\r");
            }
            else
                log_output(0, "Warning: Serial port is not open!" +"\n");
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            richTextBox1.SelectionStart = richTextBox1.Text.Length;
            richTextBox1.ScrollToCaret();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            label2.Text = "Current Temperature "+trackBar1.Value + "°F";
        }
              
        private void trackBar1_MouseCaptureChanged(object sender, EventArgs e)
        {
            string s = "|00" +  trackBar1.Value;
            transmit_data(s);
        }

        private void set_power_state()
        {
            if (checkBox1.Checked)
            {
                checkBox1.ForeColor = Color.LimeGreen;
                checkBox1.Text = "On";
                string s = "|101";
                transmit_data(s);
            }
            else
            {
                checkBox1.ForeColor = Color.Red;
                checkBox1.Text = "Off";
                string s = "|100";
                transmit_data(s);
            }
            
        }

        private void checkBox1_Click(object sender, EventArgs e)
        {
            set_power_state();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            transmit_data(textBox1.Text);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (brew_state == 1)
            {
                brew_state = 2;
                transmit_data("|130");
            }
            else if (brew_state == 2)
            {
                if (current_temp < target_temp - 12)
                    current_temp = current_temp + 10;
                else
                    current_temp++;
                trackBar1.Value = current_temp;
                label2.Text = "Current Temperature " + current_temp + "°F";
                if (current_temp > target_temp)
                {
                    set_status("Brewing");
                    brew_state = 3;
                    brew_time = 0;
                }
                else
                    transmit_data("|11" + current_temp);
            }
            else if (brew_state == 3)
            {
                brew_time++;
                transmit_data("|13" + brew_time * 10);
                if (brew_time >= 10)
                {
                    brew_state = 4;
                }
            }
            else if (brew_state == 4)
            {
                set_status("Coffee Ready");
                brew_state = 5;
            }
            else if (brew_state == 5)
            {
                if (current_temp > 71)
                {
                    if(current_temp > 82)
                        current_temp = current_temp - 10;
                    else
                        current_temp = current_temp - 1;
                    transmit_data("|11" + current_temp);
                    label2.Text = "Current Temperature " + current_temp + "°F";
                    trackBar1.Value = current_temp;
                }
                else
                    brew_state = 6;

            }
            else if (brew_state == 6)
            {
                brew_state = 7;
                set_status("Idle");
            }

        }
    }
}
